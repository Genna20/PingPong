<?php
include('index.php');

outputHeader(About);
outputBannerNavigation("About");
?>

<?php
outputFooter();
	?>