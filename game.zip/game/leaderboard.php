<?php
include('index.php');

outputHeader(Leaderboard);
outputBannerNavigation("Leaderboard");
?>

<?php
outputFooter();
	?>