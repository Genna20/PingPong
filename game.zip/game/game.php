<?php
include('index.php');

outputHeader(Game);
outputBannerNavigation("Game");
?>

<?php
outputFooter();
	?>