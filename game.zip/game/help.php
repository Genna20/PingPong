<?php
include('index.php');

outputHeader(Help);
outputBannerNavigation("Help");
?>

<?php
outputFooter();
	?>