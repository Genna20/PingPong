<?php
include('index.php');

outputHeader(Home);
outputBannerNavigation("home");
?>
<h1>HomePage</h1>
<?php
outputFooter();
	?>