<?php
include('index.php');

outputHeader(Register);
outputBannerNavigation("Register");
?>

<?php
outputFooter();
	?>